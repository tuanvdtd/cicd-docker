import express from 'express';
import mongoose from 'mongoose';


const app = express();
app.use(express.json());

const PORT = 3000;
// user: 20225423
// Kết nối đến MongoDB Atlas
const MONGODB_URI = 'mongodb+srv://20225423:DFN8wG8sDFYbmltH@cluster0.7pg6nb9.mongodb.net/?appName=Cluster0';
const DB_NAME = 'Web10';

// Connect to MongoDB Atlas

mongoose.connect(MONGODB_URI, {
	dbName: DB_NAME,
})
	.then(() => {
		console.log('Connected to MongoDB Atlas');
		app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
	})
	.catch((err) => {
		console.error('Failed to connect to MongoDB Atlas:', err);
		process.exit(1);
	});

app.get('/', (req, res) => {
	res.json({ status: 'ok' });
});

// Tạo model user
const userSchema = new mongoose.Schema({
	name: {
    type: String,
    minlength: 3,
    maxlength: 50,
    required: true,
  },
	mssv: {
    type: String,
    required: true,
    unique: true,
  },
	email: {
    type: String,
    required: true,
  },
},{
  timestamps: true,
  collection: 'Tuan.DT225423'
});

const User = mongoose.model('User', userSchema);

// route user
app.get('/users', async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  }
  catch (error) {
    res.status(500).json({ error: error.message });
  }
} 
)

app.post('/users', async (req, res) => {
  try {
    const { name, mssv, email } = req.body;
    const newUser = await User.create({ name, mssv, email });
    res.status(201).json(newUser);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/users/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/users/:id', async (req, res) => {
  try {
    const { name, mssv, email } = req.body;
    const user = await User.findByIdAndUpdate(req.params.id, { name, mssv, email }, { new: true });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/users/:id', async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id); 
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default app;

